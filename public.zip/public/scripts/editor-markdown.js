console.log('Markdown Editor loaded!');

// DOM Elements
let markdownInput, livePreview, noteTitle, subjectSelect;
let updateViewerBtn, clearBtn, exportBtn, togglePreview;
let wordCount, charCount, saveStatus, autoSaveStatus;
let toolButtons;

// Markdown parser (simple for now, can use library later)
const markdownParser = {
    parse: function(text) {
        // Convert markdown to HTML
        let html = text;
        
        // Headers
        html = html.replace(/^### (.*$)/gim, '<h3>$1</h3>');
        html = html.replace(/^## (.*$)/gim, '<h2>$1</h2>');
        html = html.replace(/^# (.*$)/gim, '<h1>$1</h1>');
        
        // Bold
        html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        html = html.replace(/__(.*?)__/g, '<strong>$1</strong>');
        
        // Italic
        html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');
        html = html.replace(/_(.*?)_/g, '<em>$1</em>');
        
        // Strikethrough
        html = html.replace(/~~(.*?)~~/g, '<del>$1</del>');
        
        // Lists
        html = html.replace(/^- (.*$)/gim, '<li>$1</li>');
        html = html.replace(/^\+ (.*$)/gim, '<li>$1</li>');
        html = html.replace(/^\* (.*$)/gim, '<li>$1</li>');
        html = html.replace(/^(\d+)\. (.*$)/gim, '<li>$2</li>');
        
        // Wrap lists
        html = html.replace(/<li>(.*?)<\/li>/gim, function(match) {
            return '<ul>' + match + '</ul>';
        });
        
        // Blockquotes
        html = html.replace(/^> (.*$)/gim, '<blockquote>$1</blockquote>');
        
        // Horizontal Rule
        html = html.replace(/^---$/gim, '<hr>');
        
        // Code blocks
        html = html.replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>');
        
        // Inline code
        html = html.replace(/`(.*?)`/g, '<code>$1</code>');
        
        // Links
        html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank">$1</a>');
        
        // Images
        html = html.replace(/!\[([^\]]+)\]\(([^)]+)\)/g, '<img src="$2" alt="$1">');
        
        // Checkboxes
        html = html.replace(/- \[ \] (.*)/g, '<input type="checkbox"> $1');
        html = html.replace(/- \[x\] (.*)/gi, '<input type="checkbox" checked> $1');
        
        // Paragraphs (convert remaining text lines to paragraphs)
        html = html.split('\n\n').map(paragraph => {
            if (!paragraph.match(/^<[^>]+>/) && paragraph.trim() !== '') {
                return '<p>' + paragraph + '</p>';
            }
            return paragraph;
        }).join('\n\n');
        
        return html;
    }
};

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    initElements();
    setupEventListeners();
    setupToolbar();
    loadLastNote();
    updateCounts();
    updatePreview();
    console.log('Markdown Editor initialized!');
});

function initElements() {
    markdownInput = document.getElementById('markdownInput');
    livePreview = document.getElementById('livePreview');
    noteTitle = document.getElementById('noteTitle');
    subjectSelect = document.getElementById('subjectSelect');
    updateViewerBtn = document.getElementById('updateViewerBtn');
    clearBtn = document.getElementById('clearBtn');
    exportBtn = document.getElementById('exportBtn');
    togglePreview = document.getElementById('togglePreview');
    wordCount = document.getElementById('wordCount');
    charCount = document.getElementById('charCount');
    saveStatus = document.getElementById('saveStatus');
    autoSaveStatus = document.getElementById('autoSaveStatus');
    toolButtons = document.querySelectorAll('.tool-btn[data-md]');
}

function setupEventListeners() {
    // Update preview as user types
    markdownInput.addEventListener('input', () => {
        updatePreview();
        updateCounts();
        autoSave();
    });
    
    // Title and subject changes
    noteTitle.addEventListener('input', autoSave);
    subjectSelect.addEventListener('change', autoSave);
    
    // Update Viewer button
    updateViewerBtn.addEventListener('click', updateViewer);
    
    // Clear button
    clearBtn.addEventListener('click', clearEditor);
    
    // Export button
    exportBtn.addEventListener('click', exportNote);
    
    // Toggle preview
    togglePreview.addEventListener('click', toggleFullscreenPreview);
    
    // Auto-save interval
    setInterval(autoSave, 30000); // Every 30 seconds
}

function setupToolbar() {
    toolButtons.forEach(button => {
        button.addEventListener('click', () => {
            insertMarkdown(button.getAttribute('data-md'));
        });
    });
    
    // Special handling for table button
    document.getElementById('insertTableBtn').addEventListener('click', insertTableMarkdown);
}

function insertMarkdown(markdown) {
    const textarea = markdownInput;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = textarea.value.substring(start, end);
    
    // Handle special cases
    let formattedText;
    
    if (markdown.includes('\n')) {
        // Multi-line markdown (like code blocks)
        const lines = markdown.split('\n');
        const beforeCursor = textarea.value.substring(0, start);
        const afterCursor = textarea.value.substring(end);
        
        // Check if we're at start of line
        const isStartOfLine = beforeCursor.endsWith('\n') || beforeCursor.length === 0;
        
        if (isStartOfLine && lines.length > 1) {
            formattedText = markdown;
        } else {
            formattedText = '\n' + markdown;
        }
    } else if (selectedText) {
        // Wrap selected text
        formattedText = markdown + selectedText + markdown;
    } else {
        // Just insert the markdown
        formattedText = markdown;
    }
    
    // Insert at cursor
    textarea.value = textarea.value.substring(0, start) + 
                     formattedText + 
                     textarea.value.substring(end);
    
    // Update cursor position
    if (selectedText && !markdown.includes('\n')) {
        textarea.selectionStart = start + markdown.length;
        textarea.selectionEnd = end + markdown.length;
    } else {
        const newPos = start + formattedText.length;
        textarea.selectionStart = textarea.selectionEnd = newPos;
    }
    
    textarea.focus();
    updatePreview();
    updateCounts();
}

function insertTableMarkdown() {
    const tableMarkdown = `
| Header 1 | Header 2 | Header 3 |
|----------|----------|----------|
| Cell 1   | Cell 2   | Cell 3   |
| Cell 4   | Cell 5   | Cell 6   |
`;
    insertMarkdown(tableMarkdown);
}

function updatePreview() {
    const markdown = markdownInput.value;
    
    // Use marked.js for parsing
    try {
        const html = marked.parse(markdown, {
            breaks: true,
            gfm: true, // GitHub Flavored Markdown (includes tables)
            tables: true // Enable table support
        });
        livePreview.innerHTML = html;
    } catch (error) {
        console.error('Markdown parsing error:', error);
        livePreview.innerHTML = `<div class="error">Error parsing markdown: ${error.message}</div>`;
    }
}

function updateCounts() {
    const text = markdownInput.value;
    const words = text.trim().split(/\s+/).filter(word => word.length > 0);
    
    wordCount.textContent = words.length;
    charCount.textContent = text.length;
}

function autoSave() {
    const noteData = getNoteData();
    localStorage.setItem('revisifyDraft', JSON.stringify(noteData));
    
    // Update status
    autoSaveStatus.textContent = `Auto-saved at ${new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}`;
    
    // Flash saved indicator
    saveStatus.textContent = '● Saved';
    saveStatus.className = 'saved';
    
    setTimeout(() => {
        saveStatus.textContent = '● Auto-save enabled';
        saveStatus.className = '';
    }, 2000);
}

function getNoteData() {
    return {
        title: noteTitle.value,
        subject: subjectSelect.value,
        content: markdownInput.value,
        timestamp: new Date().toISOString(),
        wordCount: wordCount.textContent,
        charCount: charCount.textContent
    };
}

function loadLastNote() {
    const draft = localStorage.getItem('revisifyDraft');
    if (draft) {
        try {
            const noteData = JSON.parse(draft);
            noteTitle.value = noteData.title || 'Untitled Note';
            subjectSelect.value = noteData.subject || '';
            markdownInput.value = noteData.content || '';
            console.log('Loaded draft from auto-save');
        } catch (e) {
            console.error('Error loading draft:', e);
        }
    }
}

function updateViewer() {
    const noteData = getNoteData();
    localStorage.setItem('revisifyCurrentNote', JSON.stringify(noteData));
    
    // Show success
    saveStatus.textContent = '● Sent to Viewer!';
    saveStatus.className = 'saved';
    
    // Show notification
    showNotification('Note updated! Viewer will show the latest version.');
    
    console.log('Note sent to viewer:', noteData);
}

function clearEditor() {
    if (confirm('Clear the entire editor? This will also clear auto-save.')) {
        markdownInput.value = '';
        noteTitle.value = 'Untitled Note';
        subjectSelect.selectedIndex = 0;
        localStorage.removeItem('revisifyDraft');
        updatePreview();
        updateCounts();
        
        showNotification('Editor cleared');
    }
}

function exportNote() {
    const noteData = getNoteData();
    const blob = new Blob([noteData.content], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${noteData.title.replace(/\s+/g, '-').toLowerCase()}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    showNotification('Note exported as Markdown file');
}

function toggleFullscreenPreview() {
    document.querySelector('.split-editor').classList.toggle('fullscreen-preview');
    const icon = togglePreview.querySelector('.material-icons');
    icon.textContent = document.querySelector('.split-editor').classList.contains('fullscreen-preview') 
        ? 'fullscreen_exit' 
        : 'fullscreen';
}

function showNotification(message) {
    // Create notification
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #1a73e8;
        color: white;
        padding: 12px 20px;
        border-radius: 4px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10000;
        animation: slideIn 0.3s ease;
    `;
    
    notification.textContent = message;
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
`;
document.head.appendChild(style);