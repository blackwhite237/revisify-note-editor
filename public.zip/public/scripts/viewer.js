console.log('Viewer loaded!');

document.addEventListener('DOMContentLoaded', () => {
    loadNoteFromStorage();
    setupEditButton();
});

function loadNoteFromStorage() {
    const noteData = localStorage.getItem('revisifyCurrentNote');
    
    if (!noteData) {
        document.getElementById('viewerContent').innerHTML = `
            <div class="empty-state">
                <h2>No note loaded yet</h2>
                <p>Create a note in the Editor and click "Update Viewer"</p>
                <a href="editor.html" class="btn btn-primary">
                    Go to Editor
                </a>
            </div>
        `;
        return;
    }
    
    try {
        const note = JSON.parse(noteData);
        
        // Set page title
        document.title = note.title + ' - Revisify Viewer';
        
        // Set header
        document.getElementById('viewerTitle').textContent = note.title;
        document.getElementById('viewerSubject').textContent = getSubjectName(note.subject);
        document.getElementById('viewerMeta').textContent = 
            `${note.wordCount} words • ${note.charCount} characters • ${formatDate(note.timestamp)}`;
        
        // Parse and display markdown
        const html = parseMarkdown(note.content);
        document.getElementById('viewerContent').innerHTML = html;
        
        console.log('Note loaded:', note);
        
    } catch (error) {
        console.error('Error loading note:', error);
        document.getElementById('viewerContent').innerHTML = `
            <div class="error-state">
                <h2>Error loading note</h2>
                <p>${error.message}</p>
            </div>
        `;
    }
}

function parseMarkdown(text) {
    // Use the same parser as editor
    let html = text;
    
    // Basic markdown parsing (same as editor)
    html = html.replace(/^### (.*$)/gim, '<h3>$1</h3>');
    html = html.replace(/^## (.*$)/gim, '<h2>$1</h2>');
    html = html.replace(/^# (.*$)/gim, '<h1>$1</h1>');
    html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/__(.*?)__/g, '<strong>$1</strong>');
    html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');
    html = html.replace(/_(.*?)_/g, '<em>$1</em>');
    html = html.replace(/~~(.*?)~~/g, '<del>$1</del>');
    html = html.replace(/^- (.*$)/gim, '<li>$1</li>');
    html = html.replace(/^\+ (.*$)/gim, '<li>$1</li>');
    html = html.replace(/^\* (.*$)/gim, '<li>$1</li>');
    html = html.replace(/^(\d+)\. (.*$)/gim, '<li>$2</li>');
    html = html.replace(/<li>(.*?)<\/li>/gim, '<ul>$&</ul>');
    html = html.replace(/^> (.*$)/gim, '<blockquote>$1</blockquote>');
    html = html.replace(/^---$/gim, '<hr>');
    html = html.replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>');
    html = html.replace(/`(.*?)`/g, '<code>$1</code>');
    html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank">$1</a>');
    html = html.replace(/!\[([^\]]+)\]\(([^)]+)\)/g, '<img src="$2" alt="$1">');
    html = html.replace(/- \[ \] (.*)/g, '<input type="checkbox"> $1');
    html = html.replace(/- \[x\] (.*)/gi, '<input type="checkbox" checked> $1');
    
    // Convert remaining text to paragraphs
    html = html.split('\n\n').map(paragraph => {
        if (!paragraph.match(/^<[^>]+>/) && paragraph.trim() !== '') {
            return '<p>' + paragraph + '</p>';
        }
        return paragraph;
    }).join('\n\n');
    
    return html;
}

function getSubjectName(subjectCode) {
    const subjects = {
        'math': 'Mathematics',
        'science': 'Science',
        'english': 'English',
        'history': 'History',
        'cs': 'Computer Science',
        'other': 'Other'
    };
    return subjects[subjectCode] || 'General';
}

function formatDate(isoString) {
    const date = new Date(isoString);
    return date.toLocaleDateString() + ' at ' + date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
}

function setupEditButton() {
    // Check if user is teacher/admin (for now, just show edit button)
    const isTeacher = true; // This would come from authentication
    
    if (isTeacher) {
        const editBtn = document.createElement('button');
        editBtn.className = 'btn btn-primary';
        editBtn.innerHTML = '<span class="material-icons">edit</span> Edit Note';
        editBtn.onclick = () => {
            window.location.href = 'editor.html';
        };
        
        document.querySelector('.viewer-actions').appendChild(editBtn);
    }
}